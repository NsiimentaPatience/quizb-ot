

<?php $__env->startSection('title', 'Quiz Completed'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="my-4 text-center">You have completed the quiz for <?php echo e($book->name); ?>!</h2>
        <p class="text-center">Thank you for participating.</p>
        <div class="d-flex justify-content-center">
            <a href="<?php echo e(route('books.index')); ?>" class="btn btn-primary">Go Back to Book List</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\quizb-ot\resources\views/books/completed.blade.php ENDPATH**/ ?>