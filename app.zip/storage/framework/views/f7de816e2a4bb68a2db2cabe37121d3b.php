


<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Leave a Review</h2>

    <!-- Review submission form -->
    <form action="<?php echo e(route('reviews.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <textarea name="content" class="form-control" placeholder="Write your review..." required></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Submit Review</button>
    </form>

    <hr class="my-4">

    <!-- Display all reviews with user info and replies -->
    <h3>Reviews</h3>
    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="border p-3 mb-3">
            <div class="d-flex align-items-center mb-2">
                <img src="<?php echo e(asset('storage/' . $review->user->profile_picture)); ?>" 
                     alt="<?php echo e($review->user->username); ?>" 
                     class="rounded-circle" 
                     width="50" 
                     height="50">
                <strong class="ms-3"><?php echo e($review->user->username); ?></strong>
            </div>
            <p><?php echo e($review->content); ?></p>
            <p class="text-muted">Posted on <?php echo e($review->created_at->format('F j, Y, g:i a')); ?></p>

            <!-- Replies Section -->
            <div class="ms-4">
                <?php if($review->replies->isNotEmpty()): ?>
                    <?php $__currentLoopData = $review->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="border p-2 mb-2">
                            <div class="d-flex align-items-center mb-2">
                                <img src="<?php echo e(asset('storage/' . $reply->user->profile_picture)); ?>" 
                                     alt="<?php echo e($reply->user->username); ?>" 
                                     class="rounded-circle" 
                                     width="40" 
                                     height="40">
                                <strong class="ms-3"><?php echo e($reply->user->username); ?></strong>
                            </div>
                            <p><?php echo e($reply->content); ?></p>
                            <p class="text-muted">Replied on <?php echo e($reply->created_at->format('F j, Y, g:i a')); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <p class="text-muted">No replies yet.</p>
                <?php endif; ?>

                <!-- Reply submission form for each review -->
                <form action="<?php echo e(route('reviews.reply', $review->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-2">
                        <textarea name="content" class="form-control" placeholder="Reply to this review..." required></textarea>
                    </div>
                    <button type="submit" class="btn btn-secondary btn-sm">Reply</button>
                </form>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\quizb-ot\resources\views/reviews/index.blade.php ENDPATH**/ ?>